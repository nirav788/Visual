﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.Common;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using System.IO;
using System.Net;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Newtonsoft.Json;

namespace tryout
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        Database db;
        JavaScriptSerializer json = new JavaScriptSerializer { MaxJsonLength = Int32.MaxValue };

        public WebService1()
        {
            db = DatabaseFactory.CreateDatabase();

            //Uncomment the following line if using designed components 
            //InitializeComponent(); 
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetComputerDetail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select name,Description from Computer_Detail ");
          
            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }






        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetContactus()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Address,Email,Phone_No,Website from ContactUs_Detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }




        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetClassRoomDetail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Name,Description from Class_Room ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }





        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetDance_Detail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Name,Description from Dance_Detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetMgt_Detail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Name,Description,Image from Mgt_Detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }




        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetGalary_detail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select YearID,CID,Image from Galary_detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { Image = rows }));
        }





        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetNotice_Detail    ()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Name,Description,Image from Notice_Detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }




        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetPrincipal()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Name,Description,Image from Principal ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetStaff_detail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select  Name,Qualification,Image from Staff_detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }




        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetVideo_detail()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select YearID,CID,Video from Video_detail ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetCalender_Events()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Event_Name,Event_Date from Calender_Events ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }



        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetHoliday_Master()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select Holiday_Name,Date from Holiday_Master ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public void GetLession_master()
        {
            DbCommand objCommand = db.GetSqlStringCommand("select St_Id,Div_Id,Lession,Date from Lession_master ");

            DataSet objDs = db.ExecuteDataSet(objCommand);
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row = null;
            foreach (DataRow rs in objDs.Tables[0].Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in objDs.Tables[0].Columns)
                {
                    row.Add(col.ColumnName, rs[col]);
                }
                rows.Add(row);
            }
            this.Context.Response.ContentType = "application/json; charset=utf-8";
            this.Context.Response.Write(json.Serialize(new { ContactList = rows }));
        }

    }
}
